//
//  Comment.swift
//  Final
//
//  Created by 洪逸鹏 on 2017/12/14.
//  Copyright © 2017年 洪逸鹏. All rights reserved.
//

import Foundation

struct Comment {
    
    let user: User
    let text: String
    let uid: String
    
    init(user: User, dictionary: [String: Any]) {
        self.user = user
        self.text = dictionary["text"] as? String ?? ""
        self.uid = dictionary["uid"] as? String ?? ""
    }
}
