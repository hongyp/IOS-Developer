//
//  Post.swift
//  Final
//
//  Created by 洪逸鹏 on 2017/12/12.
//  Copyright © 2017年 洪逸鹏. All rights reserved.
//

import Foundation

struct Post {
    
    var id: String?
    
    let user: User
    let imageUrl: String
    let caption: String
    let creationData: Date
    
    var hasLiked = false
    
    init(user: User,dictionary: [String: Any]) {
        self.user = user
        self.imageUrl = dictionary["imageUrl"] as? String ?? ""
        self.caption = dictionary["caption"] as? String ?? ""
        
        let secondsFrom1970 = dictionary["creationData"] as? Double ?? 0
        self.creationData = Date(timeIntervalSince1970: secondsFrom1970)
    }
}
